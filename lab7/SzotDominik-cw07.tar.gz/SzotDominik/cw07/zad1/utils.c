#include <stdlib.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/shm.h>
#include <stdbool.h>

#include "utils.h"

static int get_shared_memory(const char *filename, int size) {
    key_t key = ftok(filename, 0);
    if (key == -1) {
        return -1;
    }
    return shmget(key, size, 0644 | IPC_CREAT);
}

char *attach_shared_memory(const char* filename, int size) {
    int shared_memory_id = get_shared_memory(filename, size);
    char *shared_memory;
    if (shared_memory_id == -1) {
        fprintf(stderr, "No file: %s\n", filename);
        return NULL;
    }
    shared_memory = shmat(shared_memory_id, NULL, 0);
    if (shared_memory == (char*)(-1)) {
        fprintf(stderr, "Failed to load block: %d\n", shared_memory_id);
        return NULL;
    }
    return shared_memory;
}

bool detach_shared_memory(char *shared_memory) {
    return (shmdt(shared_memory) != -1);
}

bool destroy_shared_memory(const char *filename) {
    int shared_memory_id = get_shared_memory(filename, 0);
    if(shared_memory_id == -1) {
        return false;
    }
    return (shmctl(shared_memory_id, IPC_RMID, NULL) != -1);
}

Semaphore create_semaphore(const char *filename, int initial) {
    key_t key = ftok(getenv("HOME"), filename[0]);
    if (key == -1) {
        perror("Creating a semaphore failed on ftok");
        return -1;
    }

    Semaphore semid = semget(key, 1, 0664 | IPC_CREAT);
    if (semid == -1) {
        perror("Creating a semaphore failed on semid");
        return -1;
    }
    
    if(semctl(semid, 0, SETVAL, initial) == -1) {
        perror("Creating a semaphore failed on semctl");
        return -1;
    }
    return semid;
}

Semaphore open_semaphore(const char *filename) {
    key_t key; 
    if((key = ftok(getenv("HOME"), filename[0])) == -1) {
        return -1;
    }
    return semget(key, 1, 0);
}

void close_semaphore(Semaphore sem) {}

void unlink_semaphore(const char* filename) {
    Semaphore semid;
    if((semid = open_semaphore(filename)) == -1) {
        fprintf(stderr, "Failed to unlink semaphore.\n");
        return;
    }
    semctl(semid, 0, IPC_RMID);
}

void aquire(Semaphore sem) {
    struct sembuf operation = { 0, -1, 0 };
    if(semop(sem, &operation, 1) == -1) {
        perror("aquire"); 
    }
}

void release(Semaphore sem) {
    struct sembuf operation = { 0, 1, 0 };
    if(semop(sem, &operation, 1) == -1){
        perror("aquire");
    }
}